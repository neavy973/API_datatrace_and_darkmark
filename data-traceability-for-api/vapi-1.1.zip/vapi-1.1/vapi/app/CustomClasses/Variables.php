<?php

namespace App\CustomClasses;

class Variables
{
    public static function getAPI4OTP()
    {
        return "MTg3Mg==";
    }

    public static function getAPI4APIKey()
    {
        return "Rlp2amFGbE1nVWZucEZKRGhLeC05MnhlWHhfc0NyN1k=";
    }

    public static function getAPI6Flag()
    {
        return "ZmxhZ3thcGk2X2FmYjk2OWRiOGI2ZTI3MjY5NGI0fQ==";
    }

    public static function getAPI7SecretSalt()
    {
        return "WW91Q2FudEdldFRoaXM=";
    }

    public static function getAPI7Flag()
    {
        return "ZmxhZ3thcGk3X2U3MWI2NTA3MTY0NWUyNGVkNTBhfQ==";
    }

    public static function getAPI10Flag()
    {
        return "ZmxhZ3thcGkxMF81ZGI2MTFmN2MxZmZkNzQ3OTcxZn0=";
    }
}
