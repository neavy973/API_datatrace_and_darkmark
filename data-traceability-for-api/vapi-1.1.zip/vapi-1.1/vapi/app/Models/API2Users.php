<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class API2Users extends Model
{
    use HasFactory;

    public $timestamps = false;
    protected $fillable = ['email','password','token','姓名','性别','手机号','省/直辖市','市','区/县'];
    protected $hidden = ['password','token'];
}
