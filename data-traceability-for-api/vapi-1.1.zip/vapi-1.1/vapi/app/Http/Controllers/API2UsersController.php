<?php

namespace App\Http\Controllers;

use App\Models\API2Users;
use Illuminate\Http\Request;

class API2UsersController extends Controller
{
    public function login(Request $request)
    {

        $user=API2Users::where('email',$request->input('email'))
            ->where('password',$request->input('password'))->first();

        if($user)
        {
            return response(json_encode(array("success"=>"true","token"=>$user->token)), 200)
            ->header('Content-type', 'application/json');
        }
        else
        {
            return response(json_encode(array("success"=>"false","cause"=>"usernameOrPasswordIncorrect")), 401)
            ->header('Content-type', 'application/json');
        }

    }

    public function show(Request $request)
    {
        if($request->hasHeader('Authorization-Token') && $request->header('Authorization-Token')!="" )
        {
            $token=$request->header('Authorization-Token');

            if(API2Users::where('token',$token)->count() > 0)
            {
                return API2Users::all();
            }
            else
            {
                return response(json_encode(array("success"=>"false","cause"=>"InvalidToken")), 401)
                ->header('Content-type', 'application/json');
            }


        }

        return response(json_encode(array("success"=>"false","cause"=>"authHeaderNotSet")), 403)
            ->header('Content-type', 'application/json');

    }
	    
    public function search(Request $request,$id)
    {
    	
    	if($request->hasHeader('Authorization-Token') && $request->header('Authorization-Token')!="" )
        {
            $token=$request->header('Authorization-Token');

            if(API2Users::where('token',$token)->count() > 0)
            {
                return API2Users::find($id);
            }else
            {
            	return response(json_encode(array("success"=>"false","cause"=>"InvalidToken")), 401)
                ->header('Content-type', 'application/json');
            }
        }
        return response(json_encode(array("success"=>"false","cause"=>"authHeaderNotSet")), 403)
            ->header('Content-type', 'application/json');
    }   

    public function text(Request $request, $id)
    {
    	if($request->hasHeader('Authorization-Token') && $request->header('Authorization-Token')!="" )
        {
            $token=$request->header('Authorization-Token');

            if(API2Users::where('token',$token)->count() > 0)
            {
                return response(json_encode(array("message"=>"testlongtexttestlongtexttestlongtexttestlongtexttestlongtext")), 200)
                ->header('Content-type','application/json');
            }else
            {
            	return response(json_encode(array("success"=>"false","cause"=>"InvalidToken")), 401)
                ->header('Content-type', 'application/json');
            }
        }
        return response(json_encode(array("success"=>"false","cause"=>"authHeaderNotSet")), 403)
            ->header('Content-type', 'application/json');
    }

    public function file(Request $request, $id)
    {
    	if($request->hasHeader('Authorization-Token') && $request->header('Authorization-Token')!="" )
        {
            $token=$request->header('Authorization-Token');

            if(API2Users::where('token',$token)->count() > 0)
            {
            	$file_name= public_path('download/hello.txt');
                return response()
                ->download($file_name,'hello.txt');
            }else
            {
            	return response(json_encode(array("success"=>"false","cause"=>"InvalidToken")), 401)
                ->header('Content-type', 'application/json');
            }
        }
        return response(json_encode(array("success"=>"false","cause"=>"authHeaderNotSet")), 403)
            ->header('Content-type', 'application/json');
    }

    public function picture(Request $request, $id)
    {
    	if($request->hasHeader('Authorization-Token') && $request->header('Authorization-Token')!="" )
        {
            $token=$request->header('Authorization-Token');

            if(API2Users::where('token',$token)->count() > 0)
            {
            	$file_name= public_path('download/R-C.png');
                return response()
                ->download($file_name,'hello.png');
            }else
            {
            	return response(json_encode(array("success"=>"false","cause"=>"InvalidToken")), 401)
                ->header('Content-type', 'application/json');
            }
        }
        return response(json_encode(array("success"=>"false","cause"=>"authHeaderNotSet")), 403)
            ->header('Content-type', 'application/json');
    }







}




