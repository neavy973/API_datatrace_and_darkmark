You can import the collection and environment in your Postman or you can use the public workspace available at :

https://www.postman.com/roottusk/workspace/vapi/
