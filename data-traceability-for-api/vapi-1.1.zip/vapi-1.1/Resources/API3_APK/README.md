While Adding Base Url in the APK in the start Add it like

baseurl/vapi/

  e.g.:
  If your base url is http://127.0.0.1/
  
  Add it like http://127.0.0.1/vapi/
